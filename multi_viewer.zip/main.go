// Command example runs the multiviewer with synthetic frames and status, so you
// can see the wall end-to-end with no ffmpeg and no real streams.
//
//	go run ./example    # then open http://localhost:8099/mosaic
//
// Replace synth() with mosaic.Grabber (one per target) and wire Store.Apply to
// your prober findings (see INTEGRATION.md) to make it real.
package main

import (
	"bytes"
	"context"
	"image"
	"image/color"
	"image/jpeg"
	"log"
	"math"
	"net/http"
	"time"

	"streampulse.local/mosaic/internal/mosaic"
)

func main() {
	store := mosaic.New(30 * time.Second)
	targets := []mosaic.TargetInfo{
		{ID: "cnn-hls", Name: "CNN HLS"}, {ID: "bbc-dash", Name: "BBC DASH"},
		{ID: "sports-1", Name: "Sports 1"}, {ID: "news-2", Name: "News 2"},
		{ID: "kids-hd", Name: "Kids HD"}, {ID: "movies-4k", Name: "Movies 4K"},
	}
	for _, t := range targets {
		store.Register(t.ID, t.Name)
	}
	ctx := context.Background()
	for i, t := range targets {
		go synth(ctx, store, t.ID, i)
	}
	// one target flips critical every few seconds — the "wall goes red" demo
	go func() {
		bad := false
		for {
			time.Sleep(6 * time.Second)
			if bad = !bad; bad {
				store.Apply("sports-1", mosaic.Update{Severity: mosaic.SevCritical, Summary: "live edge frozen 14s", LiveEdgeAge: 14})
			} else {
				store.Apply("sports-1", mosaic.Update{Severity: mosaic.SevOK, Summary: "recovered", LiveEdgeAge: 2})
			}
		}
	}()
	store.Apply("news-2", mosaic.Update{Severity: mosaic.SevWarning, Summary: "PDT drift 900ms", PDTDriftMs: 900})

	mux := http.NewServeMux()
	(&mosaic.Server{Store: store, Prefix: "/mosaic"}).Register(mux)
	log.Printf("multiviewer demo: http://localhost:8099/mosaic")
	log.Fatal(http.ListenAndServe(":8099", mux))
}

func synth(ctx context.Context, s *mosaic.Store, id string, seed int) {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	phase := float64(seed)
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			img := image.NewRGBA(image.Rect(0, 0, 320, 180))
			bg := color.RGBA{uint8(20 + seed*30), 40, uint8(120 - seed*15), 255}
			for y := 0; y < 180; y++ {
				for x := 0; x < 320; x++ {
					img.SetRGBA(x, y, bg)
				}
			}
			bx := int((math.Sin(phase)*0.5 + 0.5) * 300)
			for y := 40; y < 140; y++ {
				for x := bx; x < bx+18 && x < 320; x++ {
					img.SetRGBA(x, y, color.RGBA{235, 235, 235, 255})
				}
			}
			phase += 0.4
			var buf bytes.Buffer
			_ = jpeg.Encode(&buf, img, &jpeg.Options{Quality: 70})
			s.PushFrame(id, buf.Bytes())
		}
	}
}
