# Bolting the multiviewer onto StreamPulse

`internal/mosaic` is self-contained (stdlib only). You touch it in exactly two
places in your wiring/`main`: start a grabber per target, and forward findings
into the store. No prober or `internal/alert` change is required.

## 1. Start the store, grabbers, and HTTP routes

Fold this into wherever you build targets and the `/metrics` mux.

```go
mv := mosaic.New(90 * time.Second) // hold window; see "Decay model" below

for _, t := range cfg.Targets {          // <- your config.Target
    mv.Register(t.ID, t.Name)            // <- your ID/Name fields
    g := &mosaic.Grabber{
        TargetID: t.ID,
        URL:      t.MediaURL,            // media playlist / MPD / TS URL
        FPS:      "1",                    // 1 fps thumbnails is plenty for a NOC wall
        Store:    mv,
        Logf:     log.Printf,
    }
    go g.Run(ctx)                         // ctx cancels on shutdown
}

// same mux that already serves /metrics — no second listener
(&mosaic.Server{Store: mv, Prefix: "/mosaic"}).Register(mux)
```

Wall is then at `/mosaic`, next to `/metrics`.

## 2. Forward findings — the one seam

The multiviewer is *just another notifier*: it consumes the same findings your
Slack/JSON notifiers already get, and keeps the latest per target. Add a thin
adapter that implements your existing notifier interface and calls `Apply`.

Replace the field/severity access below with your real `alert.Finding` shape:

```go
// mosaicNotifier adapts alert.Finding -> mosaic.Store. Lives in your code,
// NOT in the mosaic package, so mosaic stays free of internal/alert.
type mosaicNotifier struct{ store *mosaic.Store }

func (n mosaicNotifier) Notify(ctx context.Context, f alert.Finding) error {
    n.store.Apply(f.TargetID, mosaic.Update{
        Severity:    mosaic.ParseSeverity(f.Severity.String()), // map your tier
        Summary:     f.Message,
        LiveEdgeAge: f.LiveEdgeAgeSeconds,   // set whichever your finding carries
        PDTDriftMs:  f.PDTDriftMillis,
        Bitrate:     f.BitrateKbps,
    })
    return nil
}
```

Then register it alongside your other notifiers, e.g.
`notifiers = append(notifiers, mosaicNotifier{store: mv})`.
If your notifier signature differs (no ctx, returns nothing), match it — the
only requirement is that something calls `store.Apply` when a finding fires.

## Decay model — pick one (one line)

The tile border must return to green when a fault clears. Two ways, depending
on how your prober emits:

- **Prober re-fires a finding every poll while the fault persists** → use
  `mosaic.New(hold)` with `hold` ≈ 2–3× your poll interval. Silence == healthy;
  the border self-clears. (Recommended; matches most polling probers.)
- **Prober emits only on state transition (bad once, good once)** → use
  `mosaic.New(0)` (latch) and call `mv.Clear(f.TargetID)` from your recovery
  path.

If unsure, start with the hold window — it fails safe (a stuck grabber shows as
"no signal" via `frame_age`, and a cleared fault goes green on its own).

## What you get / what's deferred

Included: 1 fps server-side thumbnail wall, per-tile severity border + overlays
(live-edge age, PDT drift, bitrate), auto "no signal" on grabber death, all
zero-dependency (MJPEG `<img>` + SSE, no client media decode, no JS build step).

Deferred to post-skeleton, all slotting into the same tile model:
click-to-expand full-quality playback (MSE/WebRTC leg), loudness + silence per
tile (ffmpeg `ebur128`), TR 101 290 P1/P2/P3 counts from the TSDuck work, DASH
tiles, and splitting mosaic into its own service (the package boundary already
allows it — it becomes a deployment change, not a rewrite).
