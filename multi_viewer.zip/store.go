// Package mosaic is StreamPulse's monitoring multiviewer: a stateful in-memory
// store that fuses two independent inputs per target — low-rate JPEG thumbnails
// (produced by Grabber) and health status (fed from your prober's findings) —
// and serves them to a browser tile wall (see Server).
//
// The package depends only on the standard library and knows nothing about
// internal/alert, internal/hls, internal/config or the prober. The single
// integration seam is Store.Apply / Store.Clear, driven by a thin adapter you
// own in your wiring code (see INTEGRATION.md). That keeps mosaic splittable
// into its own service later without touching the prober.
package mosaic

import (
	"strings"
	"sync"
	"time"
)

// Severity mirrors your finding tiers but is defined locally to avoid coupling
// mosaic to internal/alert. Map your real severities in the adapter.
type Severity int

const (
	SevOK Severity = iota
	SevInfo
	SevWarning
	SevCritical
)

func (s Severity) String() string {
	switch s {
	case SevCritical:
		return "critical"
	case SevWarning:
		return "warning"
	case SevInfo:
		return "info"
	default:
		return "ok"
	}
}

// ParseSeverity converts a finding-severity string into a Severity.
func ParseSeverity(s string) Severity {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "critical", "crit":
		return SevCritical
	case "warning", "warn":
		return SevWarning
	case "info":
		return SevInfo
	default:
		return SevOK
	}
}

// Update carries a status change for one target. Zero-valued numeric fields are
// treated as "no change" so a partial update from one finding does not wipe
// metrics set by another.
type Update struct {
	Severity    Severity
	Summary     string  // human-readable last/worst finding, shown on the tile
	LiveEdgeAge float64 // seconds behind live edge
	PDTDriftMs  float64 // program-date-time drift, ms
	Bitrate     float64 // measured bitrate, kbps
}

// Status is the snapshot the browser consumes. Severity is the *effective*
// severity after hold-window decay.
type Status struct {
	TargetID    string    `json:"target_id"`
	Name        string    `json:"name"`
	Severity    Severity  `json:"-"`
	SeverityStr string    `json:"severity"`
	Summary     string    `json:"summary,omitempty"`
	LiveEdgeAge float64   `json:"live_edge_age_s,omitempty"`
	PDTDriftMs  float64   `json:"pdt_drift_ms,omitempty"`
	Bitrate     float64   `json:"bitrate_kbps,omitempty"`
	FrameAge    float64   `json:"frame_age_s"` // -1 = never received a frame
	UpdatedAt   time.Time `json:"updated_at"`
}

// TargetInfo is the lightweight list the page uses to build the grid.
type TargetInfo struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type targetState struct {
	id, name  string
	frames    *frameHub
	mu        sync.RWMutex
	status    Status // .Severity holds the raw (pre-decay) severity
	lastFrame time.Time
}

// Store is safe for concurrent use by many grabbers and HTTP handlers.
type Store struct {
	mu      sync.RWMutex
	targets map[string]*targetState
	order   []string
	hold    time.Duration
}

// New creates a Store. hold controls severity decay:
//
//   - hold > 0  ("re-fire" model): a target's alarm severity decays back to OK
//     if no Apply refreshes it within hold. Use when your prober re-emits a
//     finding on every poll while the condition persists. Try 2–3× poll interval.
//   - hold == 0 ("latch" model): severity stays until you call Clear. Use when
//     your prober emits findings only on state transition.
func New(hold time.Duration) *Store {
	return &Store{targets: map[string]*targetState{}, hold: hold}
}

// Register adds a target. Call once per configured target before serving.
func (s *Store) Register(id, name string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.targets[id]; ok {
		return
	}
	s.targets[id] = &targetState{id: id, name: name, frames: newFrameHub()}
	s.order = append(s.order, id)
}

func (s *Store) get(id string) *targetState {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.targets[id]
}

// PushFrame stores the latest thumbnail and fans it out to tile viewers.
func (s *Store) PushFrame(id string, jpeg []byte) {
	ts := s.get(id)
	if ts == nil {
		return
	}
	ts.mu.Lock()
	ts.lastFrame = time.Now()
	ts.mu.Unlock()
	ts.frames.push(jpeg)
}

// Apply records a finding against a target. This is the integration seam.
func (s *Store) Apply(id string, u Update) {
	ts := s.get(id)
	if ts == nil {
		return
	}
	ts.mu.Lock()
	ts.status.Severity = u.Severity
	if u.Summary != "" {
		ts.status.Summary = u.Summary
	}
	if u.LiveEdgeAge != 0 {
		ts.status.LiveEdgeAge = u.LiveEdgeAge
	}
	if u.PDTDriftMs != 0 {
		ts.status.PDTDriftMs = u.PDTDriftMs
	}
	if u.Bitrate != 0 {
		ts.status.Bitrate = u.Bitrate
	}
	ts.status.UpdatedAt = time.Now()
	ts.mu.Unlock()
}

// Clear resets a target to OK. Use from your recovery path in latch mode.
func (s *Store) Clear(id string) {
	ts := s.get(id)
	if ts == nil {
		return
	}
	ts.mu.Lock()
	ts.status.Severity = SevOK
	ts.status.Summary = ""
	ts.status.UpdatedAt = time.Now()
	ts.mu.Unlock()
}

// Snapshot returns every target's status in registration order, decay applied.
func (s *Store) Snapshot() []Status {
	s.mu.RLock()
	ids := append([]string(nil), s.order...)
	targets := s.targets
	hold := s.hold
	s.mu.RUnlock()

	now := time.Now()
	out := make([]Status, 0, len(ids))
	for _, id := range ids {
		ts := targets[id]
		ts.mu.RLock()
		st := ts.status
		eff := st.Severity
		if hold > 0 && !st.UpdatedAt.IsZero() && now.Sub(st.UpdatedAt) > hold {
			eff = SevOK
		}
		frameAge := -1.0
		if !ts.lastFrame.IsZero() {
			frameAge = now.Sub(ts.lastFrame).Seconds()
		}
		out = append(out, Status{
			TargetID: id, Name: ts.name,
			Severity: eff, SeverityStr: eff.String(),
			Summary: st.Summary, LiveEdgeAge: st.LiveEdgeAge,
			PDTDriftMs: st.PDTDriftMs, Bitrate: st.Bitrate,
			FrameAge: frameAge, UpdatedAt: st.UpdatedAt,
		})
		ts.mu.RUnlock()
	}
	return out
}

// Targets lists registered targets for the grid builder.
func (s *Store) Targets() []TargetInfo {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]TargetInfo, 0, len(s.order))
	for _, id := range s.order {
		out = append(out, TargetInfo{ID: id, Name: s.targets[id].name})
	}
	return out
}

// SubscribeFrames returns a channel of JPEG frames (seeded with the latest) and
// a cancel func the caller must invoke. Returns (nil, noop) for unknown targets.
func (s *Store) SubscribeFrames(id string) (<-chan []byte, func()) {
	ts := s.get(id)
	if ts == nil {
		return nil, func() {}
	}
	return ts.frames.subscribe()
}

// frameHub is a latest-wins fan-out. Slow viewers drop frames rather than
// applying backpressure to the grabber — correct for a thumbnail wall.
type frameHub struct {
	mu     sync.RWMutex
	latest []byte
	subs   map[chan []byte]struct{}
}

func newFrameHub() *frameHub { return &frameHub{subs: map[chan []byte]struct{}{}} }

func (h *frameHub) push(b []byte) {
	h.mu.Lock()
	h.latest = b
	for ch := range h.subs {
		select {
		case ch <- b:
		default:
		}
	}
	h.mu.Unlock()
}

func (h *frameHub) subscribe() (<-chan []byte, func()) {
	ch := make(chan []byte, 1)
	h.mu.Lock()
	if h.latest != nil {
		ch <- h.latest
	}
	h.subs[ch] = struct{}{}
	h.mu.Unlock()
	return ch, func() {
		h.mu.Lock()
		delete(h.subs, ch)
		h.mu.Unlock()
	}
}
